function checkWordCategory(word) {
    let fs = require('fs');
    let filePath = 'public/json/wordss.json';
    let data = fs.readFileSync(filePath);
    let json = JSON.parse(data);

    for (let category in json) {
        if (json[category].includes(word)) {
            return category;
        }
    }

    return "not found";
}

// Test the function
console.log(checkWordCategory("人")); // Output: words0
console.log(checkWordCategory("是")); // Output: words2
console.log(checkWordCategory("想")); // Output: words3
console.log(checkWordCategory("我")); // Output: words4
console.log(checkWordCategory("快")); // Output: not found


/*
    // success on init, thus keep as backup away from lyrics.ejs
        async function init() {
            const jsonUrl = 'json/wordss.json';
            const jsonData = await loadJSON(jsonUrl);

            if (jsonData) {
                initializeWordLists(jsonData);
            } else {
                console.error('Failed to initialize word lists.');
            }

            $("#processButton").on('click', processLyrics);

            $("#lyricsDisplay").on('click', '.tone', function () {
                const tone = $(this).data('tone');
                if (tone && tone !== '-') {
                    showSuggestions(tone);
                }
            });

            // Test wordsData
            const testString = "情在這手";
            const testChars = Array.from(testString);
            let result = "";
                testChars.forEach(char => {
                if (wordsData.words0.has(char)) {
                    result += char + ": 0\n";
                } else if (wordsData.words2.has(char)) {
                    result += char + ": 2\n";
                } else if (wordsData.words4.has(char)) {
                    result += char + ": 4\n";
                } else if (wordsData.words3.has(char)) {
                    result += char + ": 3\n";
                } else {
                    result += char + ": X\n";
                }
            });
            //alert(result);
        }

        $(document).ready(init);


*/