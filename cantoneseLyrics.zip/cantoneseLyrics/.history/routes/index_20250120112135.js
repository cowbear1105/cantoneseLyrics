var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: '0243 廣東話填詞' });
  //res.redirect('/1234.html');
});

/* GET lyrics page */
router.get('/lyrics', function(req, res, next) {
  res.render('lyrics', { title: '0243 填詞器 - 歌詞編輯' });
});

module.exports = router;
