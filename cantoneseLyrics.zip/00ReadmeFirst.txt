0243 即點即有填詞器 本地使方方法：

1. 先去 node.js 官網下載並安裝 https://nodejs.org/zh-tw/download
2. 首次才需要雙擊 01installNpm.bat 安裝對應的 package
3. 雙擊 02RuncantoneseLyrics.bat 啟動本地服侍器去 8320 port, 不要關閉。
4. 雙擊 03viewInBrowser.bat 或直接去 http://localhost:8320 便可以使用。

日後只需要重複 3和4 動作便能輕鬆本地 0243 即點即有填詞。

費用：全免

製作人：Terence 
